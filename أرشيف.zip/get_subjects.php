<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "school_db";

$conn = new mysqli($servername, $username, $password, $dbname);
mysqli_set_charset($conn,"utf8");

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$teacher_id = $_GET['teacher_id'];

// جلب معلومات المعلم
$teacher_sql = "SELECT teacher_id, name, phone, email FROM teachers WHERE teacher_id = $teacher_id";
$teacher_result = $conn->query($teacher_sql);
$teacher_data = $teacher_result->fetch_assoc();

// جلب المواد
$subjects_sql = "SELECT subject_id, name, teacher_id FROM subjects WHERE teacher_id = $teacher_id";
$subjects_result = $conn->query($subjects_sql);

$data = array(
    'teacher' => $teacher_data,
    'subjects' => array()
);

while($row = $subjects_result->fetch_assoc()) {
    $data['subjects'][] = $row;
}

echo json_encode($data);

$conn->close();
?>
