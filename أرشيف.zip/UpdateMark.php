<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "school_db";

$conn = new mysqli($servername, $username, $password, $dbname);
mysqli_set_charset($conn,"utf8");

if ($conn->connect_error) {
    die("Connection failed");
}

$mark_id = $_POST['mark_id'];
$mark_value = $_POST['mark_value'];

$sql = "UPDATE marks SET mark_value = $mark_value WHERE mark_id = $mark_id";

if ($conn->query($sql) === TRUE) {
    echo "Done";
} else {
    echo "Error";
}

$conn->close();
?>
