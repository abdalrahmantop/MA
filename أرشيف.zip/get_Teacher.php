<?php
header('Content-Type: application/json');
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "school_db";

$conn = new mysqli($servername, $username, $password, $dbname);
mysqli_set_charset($conn,"utf8");

if ($conn->connect_error) {
    echo json_encode(['status'=>'error','message'=>'Connection failed']);
    exit();
}

$teacher_id = $_GET['teacher_id'];

$result = $conn->query("SELECT * FROM teachers WHERE teacher_id = $teacher_id");

if ($result->num_rows > 0) {
    $teacher = $result->fetch_assoc();
    echo json_encode(['status'=>'success', 'teacher'=>$teacher]);
} else {
    echo json_encode(['status'=>'error','message'=>'Teacher not found']);
}

$conn->close();
?>
