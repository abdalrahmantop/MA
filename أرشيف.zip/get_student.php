<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "school_db";

$conn = new mysqli($servername, $username, $password, $dbname);
mysqli_set_charset($conn,"utf8");

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$subject_id = $_GET['subject_id'];

$sql = "SELECT s.student_id, s.name 
        FROM students s
        INNER JOIN student_subjects ss ON s.student_id = ss.student_id
        WHERE ss.subject_id = '$subject_id'";

$result = $conn->query($sql);

$students = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $students[] = $row;
    }
}

echo json_encode($students);

$conn->close();
?>
