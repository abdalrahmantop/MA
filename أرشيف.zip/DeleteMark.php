<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "school_db";

$conn = new mysqli($servername, $username, $password, $dbname);
mysqli_set_charset($conn,"utf8");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$mark_id = $_POST['mark_id'];

$sql = "DELETE FROM marks WHERE mark_id = $mark_id";

if ($conn->query($sql) === TRUE) {
    echo "Done";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
