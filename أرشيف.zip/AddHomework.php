<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "school_db";

$conn = new mysqli($servername, $username, $password, $dbname);
mysqli_set_charset($conn,"utf8");

$subject_id = $_POST['subject_id'];
$title = $_POST['title'];
$description = $_POST['description'];
$due_date = $_POST['due_date'];
$file_path = $_POST['file_path'];

// تهيئة جملة الإدخال
$sql = "INSERT INTO homeworks (subject_id, title, description, due_date, file_path)
        VALUES ($subject_id, '$title', '$description', '$due_date', '$file_path')";

if ($conn->query($sql) === TRUE) {
    echo "Done";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
