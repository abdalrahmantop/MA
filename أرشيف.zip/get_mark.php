<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "school_db";

$conn = new mysqli($servername, $username, $password, $dbname);
mysqli_set_charset($conn,"utf8");

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$student_id = $_GET['student_id'];
$subject_id = $_GET['subject_id'];

$sql = "SELECT mark_id, mark_value, mark_type 
        FROM marks 
        WHERE student_id = '$student_id' AND subject_id = '$subject_id'";

$result = $conn->query($sql);

$marks = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $marks[] = $row;
    }
}

echo json_encode($marks);

$conn->close();
?>
