<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "school_db";

 
$conn = new mysqli($servername, $username, $password, $dbname);
mysqli_set_charset($conn,"utf8");

 

$student_id = $_POST['student_id'];
$subject_id = $_POST['subject_id'];
$mark_value = $_POST['mark_value'];
$mark_type  = $_POST['mark_type'];


$sql = "INSERT INTO marks (student_id, subject_id, mark_value, mark_type)
        VALUES ($student_id, $subject_id, $mark_value, '$mark_type')";

if ($conn->query($sql) === TRUE) {
    echo " Done ";
} else {
    echo " Error: " . $conn->error;
}

 
$conn->close();
?>
